
#include "State.hpp"

State::State() { 
	board.push_back(std::vector<bool>());
	board[0].push_back(false);
}
int State::getBoardSize(){ 
	return 0; 
}
