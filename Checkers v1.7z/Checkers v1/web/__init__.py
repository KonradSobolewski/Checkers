#komentarz
