## @file current/models.py
#  @brief current server status model

"""current state module"""



