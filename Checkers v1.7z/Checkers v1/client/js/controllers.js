/// @file controllers.js
/// @brief AngularJS controllers

angular.module('myAppControllers', [])
		.controller('settingsController',['$scope', 'srvInfo', function($scope, srvInfo) {
		 	$scope.check = function() {
				srvInfo.getCppNumber(
				function(data){
					$scope.counter = data;
				});
			};
		 }]);


